Read Me
Create a new game on Magic Dosbox and put a 
name and the direction with doom files, search how to 
watch secret folders in zarchiver or the 
files explorer you want, go to .MagicBox>
GamesLite>Data and copy the rare name of the folder 
now extract Doom Virtual Controller.zip and 
search the file "rename", rename the folder
with the name you have copy and now copy 
the file and go to .MagicBox>GamesLite>Data 
and replace the folder.
For more information go to
bleeiter.github.io/doomvirtualcontroller/
and click "Github Repository"